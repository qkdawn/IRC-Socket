"""Shared IRC protocol primitives."""
