"""IRC command bot."""
